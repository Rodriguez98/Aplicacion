package com.kevodriguez.registro_citas_medicas.Repositories

import androidx.lifecycle.LiveData
import com.kevodriguez.registro_citas_medicas.Daos.PacienteDao
import com.kevodriguez.registro_citas_medicas.Models.Paciente

class PacienteRepository(private val pacienteDao: PacienteDao) {

    val allPacientes: LiveData<List<Paciente>> = pacienteDao.getAll()

    suspend fun insert(paciente: Paciente) {
        pacienteDao.insert(paciente)
    }
}