package com.kevodriguez.registro_citas_medicas.Activities

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import com.kevodriguez.registro_citas_medicas.R
import kotlinx.android.synthetic.main.activity_cita.*

class CitaActivity : AppCompatActivity() {

    private lateinit var editCitaView: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cita)

        editCitaView = findViewById(R.id.etNombre)
        /*editCitaView = findViewById(R.id.etApellido)
        editCitaView = findViewById(R.id.etNumero)
        editCitaView = findViewById(R.id.etFecha)*/

        val button = findViewById<Button>(R.id.button_save)
        button.setOnClickListener {
            val replyIntent = Intent()
            if (TextUtils.isEmpty(editCitaView.text)) {
                setResult(Activity.RESULT_CANCELED, replyIntent)
            } else {

                val cita = editCitaView.text.toString()
                replyIntent.putExtra("nombre", cita)
                /* replyIntent.putExtra("Apellido", cita)
            replyIntent.putExtra("Numero", cita)
            replyIntent.putExtra("Fecha", cita)*/
                setResult(Activity.RESULT_OK, replyIntent)
            }
            finish()
        }
        /*  companion object {
        const val EXTRA_REPLY = "com.example.android.citalistsql.REPLY"
    }*/
    }
}
