package com.kevodriguez.registro_citas_medicas.Adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.kevodriguez.registro_citas_medicas.Models.Cita
import com.kevodriguez.registro_citas_medicas.R

class CitaListAdapter internal constructor(
    context: Context
) : RecyclerView.Adapter<CitaListAdapter.CitaViewHolder>() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)
    private var citas = emptyList<Cita>()

    inner class CitaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val citaItemView: TextView = itemView.findViewById(R.id.textView)
        val citaItemView1: TextView = itemView.findViewById(R.id.textView2)
        val citaItemView2: TextView = itemView.findViewById(R.id.textView3)
      // val citaItemView3: TextView = itemView.findViewById(R.id.textView4)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CitaViewHolder {
        val itemView = inflater.inflate(R.layout.recyclerview_item, parent, false)
        return CitaViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: CitaViewHolder, position: Int) {
        val current = citas[position]
        holder.citaItemView.text = current.pacienteId.toString()
        holder.citaItemView1.text = current.especialidadId.toString()
        holder.citaItemView2.text = current.fechaCita.toString()
    }

    internal fun setCitas(citas: List<Cita>){
        this.citas= citas
        notifyDataSetChanged()
    }

    override fun getItemCount() = citas.size
}