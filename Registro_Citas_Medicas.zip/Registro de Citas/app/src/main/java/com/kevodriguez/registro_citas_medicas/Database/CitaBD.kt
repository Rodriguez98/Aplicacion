package com.kevodriguez.registro_citas_medicas.Database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.kevodriguez.registro_citas_medicas.Daos.CitaDao
import com.kevodriguez.registro_citas_medicas.Daos.EspecialidadDao
import com.kevodriguez.registro_citas_medicas.Daos.PacienteDao
import com.kevodriguez.registro_citas_medicas.Models.Cita
import com.kevodriguez.registro_citas_medicas.Models.Especialidad
import com.kevodriguez.registro_citas_medicas.Models.Paciente

@Database(entities = arrayOf(Cita::class, Paciente::class, Especialidad::class), version = 1, exportSchema = false)
public abstract class CitaBD : RoomDatabase() {

    abstract fun citaDao(): CitaDao
    abstract fun pacienteDao(): PacienteDao
    abstract fun espcialidadDao(): EspecialidadDao

    companion object {
        @Volatile
        private var INSTANCE: CitaBD? = null

        fun getDatabase(context: Context): CitaBD{
            val tempInstance = INSTANCE
            if (tempInstance != null) {
                return tempInstance
            }
            synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CitaBD::class.java,
                    "cita_database"
                ).build()
                INSTANCE = instance
                return instance
            }
        }
    }
}