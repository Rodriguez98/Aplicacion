package com.kevodriguez.registro_citas_medicas.ViewModels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.kevodriguez.registro_citas_medicas.Database.CitaBD
import com.kevodriguez.registro_citas_medicas.Models.Paciente
import com.kevodriguez.registro_citas_medicas.Repositories.PacienteRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PacienteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PacienteRepository

    val allPacientes: LiveData<List<Paciente>>

    init {
        val pacienteDao = CitaBD.getDatabase(application).pacienteDao()
        repository = PacienteRepository(pacienteDao)
        allPacientes = repository.allPacientes
    }

    fun insert(paciente: Paciente) = viewModelScope.launch(Dispatchers.IO) {
        repository.insert(paciente)
    }
}