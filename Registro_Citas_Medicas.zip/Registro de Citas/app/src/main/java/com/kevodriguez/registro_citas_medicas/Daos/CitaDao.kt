package com.kevodriguez.registro_citas_medicas.Daos

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.kevodriguez.registro_citas_medicas.Models.Cita
import com.kevodriguez.registro_citas_medicas.Models.Especialidad
import com.kevodriguez.registro_citas_medicas.Models.Paciente

@Dao
interface CitaDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert (cita: Cita)

    @Query(" DELETE FROM cita")
    fun deleteAll()

    @Query("SELECT * FROM paciente INNER JOIN cita ON paciente.id = cita.paciente_id WHERE cita.especialidad_id = especialidad_id")
    fun getPacientesForEspecialidad(): LiveData<List<Paciente>>

    @Query("SELECT * FROM especialidad INNER JOIN cita ON especialidad.id = cita.especialidad_id WHERE cita.paciente_id = paciente_id")
    fun getEspecialidadForPacientes(): LiveData<List<Especialidad>>

}