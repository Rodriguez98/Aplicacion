package com.kevodriguez.registro_citas_medicas.ViewModels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.kevodriguez.registro_citas_medicas.Database.CitaBD
import com.kevodriguez.registro_citas_medicas.Models.Especialidad
import com.kevodriguez.registro_citas_medicas.Models.Paciente
import com.kevodriguez.registro_citas_medicas.Repositories.EspecialidadRepository
import com.kevodriguez.registro_citas_medicas.Repositories.PacienteRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class EspecialidadViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: EspecialidadRepository

    val allEspecialidades: LiveData<List<Especialidad>>

    init {
        val especialidadDao = CitaBD.getDatabase(application).espcialidadDao()
        repository = EspecialidadRepository(especialidadDao)
        allEspecialidades = repository.allEspecialidades
    }

    fun insert(especialidad: Especialidad) = viewModelScope.launch(Dispatchers.IO) {
        repository.insert(especialidad)
    }
}