package com.kevodriguez.registro_citas_medicas.Repositories

import androidx.lifecycle.LiveData
import com.kevodriguez.registro_citas_medicas.Daos.EspecialidadDao
import com.kevodriguez.registro_citas_medicas.Models.Especialidad

class EspecialidadRepository(private val especialidadDao: EspecialidadDao) {

    val allEspecialidades: LiveData<List<Especialidad>> = especialidadDao.getEspecialidad()

    suspend fun insert(especialidad: Especialidad) {
        especialidadDao.insert(especialidad)
    }
}