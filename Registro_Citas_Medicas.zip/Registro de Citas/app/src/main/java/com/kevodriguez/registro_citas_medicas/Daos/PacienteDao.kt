package com.kevodriguez.registro_citas_medicas.Daos

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.kevodriguez.registro_citas_medicas.Models.Paciente

@Dao
interface PacienteDao {
    @Query("SELECT * FROM paciente")
    fun getAll(): LiveData<List<Paciente>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert (paciente: Paciente)

    @Query(" DELETE FROM paciente")
    fun deleteAll()
}