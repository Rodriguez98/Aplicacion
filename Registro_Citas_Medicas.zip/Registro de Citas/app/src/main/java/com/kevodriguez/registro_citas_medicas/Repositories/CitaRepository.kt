package com.kevodriguez.registro_citas_medicas.Repositories

import androidx.lifecycle.LiveData
import com.kevodriguez.registro_citas_medicas.Daos.CitaDao
import com.kevodriguez.registro_citas_medicas.Models.Cita
import com.kevodriguez.registro_citas_medicas.Models.Especialidad
import com.kevodriguez.registro_citas_medicas.Models.Paciente

class CitaRepository(private val citaDao: CitaDao) {

    val allEspecialidades: LiveData<List<Especialidad>> = citaDao.getEspecialidadForPacientes()
    val allPacientes: LiveData<List<Paciente>> = citaDao.getPacientesForEspecialidad()

    suspend fun insert(cita: Cita) {
        citaDao.insert(cita)
    }
}