package com.kevodriguez.registro_citas_medicas.Activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.kevodriguez.registro_citas_medicas.Adapters.CitaListAdapter
import com.kevodriguez.registro_citas_medicas.Models.Cita
import com.kevodriguez.registro_citas_medicas.Models.Especialidad
import com.kevodriguez.registro_citas_medicas.Models.Paciente
import com.kevodriguez.registro_citas_medicas.R
import com.kevodriguez.registro_citas_medicas.ViewModels.CitaViewModel
import kotlinx.android.synthetic.main.activity_cita.*


class MainActivity : AppCompatActivity() {

        var citas = mutableListOf<Cita>()
        private lateinit var citaViewModel: CitaViewModel
        private val newCitaActivityRequestCode = 1

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
            val adapter = CitaListAdapter(this)
            recyclerView.adapter = adapter
            recyclerView.layoutManager = LinearLayoutManager(this)

            citaViewModel = ViewModelProvider(this).get(CitaViewModel::class.java)

            citaViewModel.allPacientes.observe(this, Observer { citas ->
                citas?.let { adapter.setCitas(listOf(Cita(0,0,0)))}
            })
            citaViewModel.allEspecialidades.observe(this, Observer { citas ->
                citas?.let { adapter.setCitas(listOf(Cita(0,0,0)))}
            })

            val addCita = findViewById<Button>(R.id.btnAddCita)
            addCita.setOnClickListener {
                val intent = Intent(this, CitaActivity::class.java)
                startActivityForResult(intent, newCitaActivityRequestCode)
            }
        }

        override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
            super.onActivityResult(requestCode, resultCode, data)

            if (requestCode == newCitaActivityRequestCode && resultCode == Activity.RESULT_OK) {
                /*data?.getStringExtra(CitaActivity.EXTRA_REPLY)?.let {
                    val cita = Cita(it)
                    citaViewModel.insert(cita)*/
                var numero = etNumero.toString()
                var fecha = etFecha.toString()
                var paciente = Paciente(
                    id = 0,
                    nombre = etNombre.toString(),
                    apellido = etApellido.toString(),
                    numCelular = numero.toInt()
                )
                var especialidad = Especialidad(
                    id = 0,
                    especialidad = spEspecialidad.toString()
                )
                var cita =
                    Cita(pacienteId = paciente.hashCode(), especialidadId = especialidad.hashCode(), fechaCita = fecha.toInt())
                citaViewModel.insert(cita)
            } else {
                Toast.makeText(
                    applicationContext,
                    R.string.empty_not_saved,
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

