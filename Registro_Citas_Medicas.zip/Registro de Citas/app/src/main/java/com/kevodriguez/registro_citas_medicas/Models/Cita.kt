package com.kevodriguez.registro_citas_medicas.Models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import java.util.*

@Entity(
    tableName = "cita",
    primaryKeys = arrayOf("paciente_id", "especialidad_id"),
    foreignKeys = arrayOf(
        ForeignKey(
            entity = Paciente::class,
            parentColumns = arrayOf("id"),
            childColumns = arrayOf("paciente_id")
        ),
        ForeignKey(
            entity = Especialidad::class,
            parentColumns = arrayOf("id"),
            childColumns = arrayOf("especialidad_id")
        )
    )
)

data class Cita(
    @ColumnInfo(name = "paciente_id") var pacienteId: Int,
    @ColumnInfo(name = "especialidad_id") var especialidadId: Int,
    @ColumnInfo(name = "fecha_cita") var fechaCita: Int
)