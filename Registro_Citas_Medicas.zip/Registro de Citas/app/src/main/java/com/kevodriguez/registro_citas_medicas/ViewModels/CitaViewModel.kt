package com.kevodriguez.registro_citas_medicas.ViewModels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.kevodriguez.registro_citas_medicas.Database.CitaBD
import com.kevodriguez.registro_citas_medicas.Models.Cita
import com.kevodriguez.registro_citas_medicas.Models.Especialidad
import com.kevodriguez.registro_citas_medicas.Models.Paciente
import com.kevodriguez.registro_citas_medicas.Repositories.CitaRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CitaViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CitaRepository

    val allPacientes: LiveData<List<Paciente>>
    val allEspecialidades: LiveData<List<Especialidad>>

    init {
        val citaDao = CitaBD.getDatabase(application).citaDao()
        repository = CitaRepository(citaDao)
        allPacientes = repository.allPacientes
        allEspecialidades = repository.allEspecialidades
    }

    fun insert(cita: Cita) = viewModelScope.launch(Dispatchers.IO) {
        repository.insert(cita)
    }
}