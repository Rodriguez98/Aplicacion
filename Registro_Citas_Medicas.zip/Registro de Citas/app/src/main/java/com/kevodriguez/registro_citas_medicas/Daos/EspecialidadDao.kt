package com.kevodriguez.registro_citas_medicas.Daos

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.kevodriguez.registro_citas_medicas.Models.Especialidad

@Dao
interface EspecialidadDao {
    @Query("SELECT * FROM especialidad")
    fun getEspecialidad(): LiveData<List<Especialidad>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert (especialidad: Especialidad)

    @Query(" DELETE FROM especialidad")
    fun deleteAll()
}